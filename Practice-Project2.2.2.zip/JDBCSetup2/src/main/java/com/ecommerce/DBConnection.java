package com.ecommerce;



import java.sql.*;
public class DBConnection {
        
        public static void main(String[]args) throws SQLException{
        	try
        	{
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                Connection conObj = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecommerce","root", "Mysql@root123");
                if(conObj!=null)
                	System.out.println("DB connected...");
        	}
        	catch(Exception ex)
        	{
        		System.out.print(ex);
        	}
        	
        }
        
}
         

